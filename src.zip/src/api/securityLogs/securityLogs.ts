export enum SecurityLogAction {
	LOGIN = "login",
	LOGOUT = "logout",
	ATTEMPT_FAILED = "attempt_failed",
}
